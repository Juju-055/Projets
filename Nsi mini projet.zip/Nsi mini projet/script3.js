function changeImage(jsp) {
    var image = document.querySelector(".center"); 
    image.src = jsp; 
}

function resetImage(jsp1) {
    var image = document.querySelector(".center"); 
    image.src = jsp1; 
}