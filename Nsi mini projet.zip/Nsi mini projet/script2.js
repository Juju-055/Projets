function toggleText() {
    var texteComplet = document.getElementById("texteComplet");
    if (texteComplet.style.display === "none") {
        texteComplet.style.display = "block";
    } else {
        texteComplet.style.display = "none";
    }
}