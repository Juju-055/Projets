function changeCouleur(id) {
    var text = document.getElementById(id);
    text.style.color = "grey"; 
}

function changeCouleurRED(id) {
    var text = document.getElementById(id);
    text.style.color = "red"; 
}